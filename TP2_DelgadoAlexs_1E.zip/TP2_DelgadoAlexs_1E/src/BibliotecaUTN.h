#ifndef BIBLIOTECAUTN_H_
#define BIBLIOTECAUTN_H_

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int ingresarEntero(char mensaje[]);
int getString(char cadena[], char mensaje[], int tam);
float IngresarFlotante(char mensaje[]);
char confirmar();


#endif
